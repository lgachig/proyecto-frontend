"use client";
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export function useAuth() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function initializeAuth() {
      // 1. Intentar recuperar sesión existente de la cookie/storage
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user && mounted) {
        setUser(session.user);
        // Cargar perfil si existe sesión
        const { data: prof } = await supabase
          .from('profiles')
          .select('*, roles(name)')
          .eq('id', session.user.id)
          .single();
        if (mounted) setProfile(prof);
      }
      if (mounted) setLoading(false);
    }

    initializeAuth();

    // 2. Escuchar cambios de estado (Login, Logout, Token Refreshed)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (mounted) {
        if (session) {
          setUser(session.user);
          // Si es un evento de login o cambio, refrescamos el perfil
          if (event === 'SIGNED_IN' || event === 'USER_UPDATED') {
            const { data: prof } = await supabase
              .from('profiles')
              .select('*, roles(name)')
              .eq('id', session.user.id)
              .single();
            setProfile(prof);
          }
        } else {
          setUser(null);
          setProfile(null);
        }
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return { user, profile, loading };
}

export const register = async ({ email, password, full_name, institutional_id, role_id }) => {
  // 1. REGISTRO EN AUTH (Sistema de acceso)
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name,
        institutional_id,
        role_id,
      }
    }
  });

  if (authError) throw authError;

  // 2. REGISTRO EN LA TABLA PROFILES (Donde viste los NULL)
  // Usamos el ID que nos dio el paso anterior
  const { error: profileError } = await supabase
    .from('profiles')
    .insert({
      id: authData.user.id, // Vincula el perfil con el usuario de Auth
      full_name: full_name,
      institutional_id: institutional_id,
      role_id: role_id,
      is_active: true,
      updated_at: new Date().toISOString(),
    });

  if (profileError) {
    // Si falla el perfil, podríamos tener un problema de consistencia
    console.error("Error al crear el perfil en la tabla:", profileError);
    throw profileError;
  }

  return authData;
};

export function useCurrentUser() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Obtener sesión actual al cargar
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      setLoading(false);
    };

    getSession();

    // 2. Escuchar cambios en la sesión (Login/Logout)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  return user; // Devuelve el objeto del usuario o null
}