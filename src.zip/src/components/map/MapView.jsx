"use client";
import { MapContainer, TileLayer, Polyline, Marker, useMap } from "react-leaflet";
import { useState, useCallback, useEffect, useRef } from "react";
import { useSlots } from "../../hooks/useParking";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const COORD_GARITA = { lat: -0.19788047822831814, lng: -78.50234205390771 };

// CONTROLADOR CORREGIDO (Evita el error de renderizado y tamaño de array)
function MapController({ userLocation, selectedSlot }) {
  const map = useMap();
  
  useEffect(() => {
    if (!map) return;

    if (selectedSlot?.latitude) {
      map.flyTo([selectedSlot.latitude, selectedSlot.longitude], 20, { duration: 1.5 });
    } else if (userLocation?.lat) {
      map.flyTo([userLocation.lat, userLocation.lng], 18);
    }
    // Usamos propiedades específicas como dependencias para evitar que el array cambie de tamaño
  }, [map, userLocation?.lat, userLocation?.lng, selectedSlot?.id]);

  return null;
}

export default function MarkingMap() {
  const { data: slotsData, isLoading } = useSlots();
  const [mounted, setMounted] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [routePoints, setRoutePoints] = useState([]);
  const [userLocation, setUserLocation] = useState(null);
  const [eta, setEta] = useState(null);

  // Función de ruteo optimizada
  const trazarRuta = useCallback((slot, location) => {
    if (!location?.lat || !slot?.latitude) return;
    
    const waypoints = `${location.lng},${location.lat};${COORD_GARITA.lng},${COORD_GARITA.lat};${slot.longitude},${slot.latitude}`;
    
    fetch(`https://router.project-osrm.org/route/v1/driving/${waypoints}?overview=full&geometries=geojson`)
      .then(res => res.json())
      .then(data => {
        if (data.routes?.[0]) {
          const coords = data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
          setRoutePoints(coords);
          setEta(Math.round(data.routes[0].duration / 60));
        }
      })
      .catch(err => console.error("Error en ruteo:", err));
  }, []);

  // GPS Inicial con timeout mayor para evitar el error de "No se pudo determinar"
  useEffect(() => {
    setMounted(true);
    if (typeof window !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        },
        (err) => console.warn("GPS no disponible al inicio, usando centro UCE"),
        { enableHighAccuracy: false, timeout: 10000 }
      );
    }
  }, []);

  // Seleccionar automáticamente el primero disponible al cargar
  useEffect(() => {
    if (userLocation && slotsData && !selectedSlot) {
      const disponible = slotsData.find(s => s.status === 'available');
      if (disponible) {
        setSelectedSlot(disponible);
        trazarRuta(disponible, userLocation);
      }
    }
  }, [userLocation, slotsData, selectedSlot, trazarRuta]);

  if (!mounted || isLoading) return null;

  return (
    <div className="w-full h-full relative">
      {/* HUD de navegación */}
      {selectedSlot && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 z-[1000] w-[90%] max-w-sm">
          <div className="bg-gray-900/95 border-2 border-blue-500 p-4 rounded-3xl shadow-2xl flex items-center justify-between text-white backdrop-blur-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center font-black text-xl border border-white/20">
                {selectedSlot.number}
              </div>
              <div className="leading-tight">
                <p className="text-blue-400 text-[10px] font-black uppercase tracking-tighter italic">Guía UCE</p>
                <p className="font-bold text-sm uppercase">Puesto {selectedSlot.number}</p>
              </div>
            </div>
            <div className="text-right border-l border-gray-700 pl-4">
              <p className="text-gray-400 text-[10px] font-black uppercase">Llegada</p>
              <p className="text-xl font-black">{eta !== null ? `${eta} min` : '--'}</p>
            </div>
          </div>
        </div>
      )}

      <MapContainer center={[-0.1990, -78.5029]} zoom={19} className="w-full h-full" zoomControl={false}>
        <TileLayer 
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" 
          maxZoom={22}
          attribution='&copy; OpenStreetMap contributors'
        />
        
        <MapController userLocation={userLocation} selectedSlot={selectedSlot} />

        {/* Marcador de Usuario */}
        {userLocation && (
          <Marker position={[userLocation.lat, userLocation.lng]} icon={L.divIcon({
            html: `<div class="relative"><div class="absolute -inset-2 bg-blue-500/20 rounded-full animate-pulse"></div><div style="background:#3B82F6; width:14px; height:14px; border-radius:50%; border:2px solid white; box-shadow:0 0 10px blue;"></div></div>`,
            className: "", iconSize: [14, 14]
          })} />
        )}

        {/* Marcadores de Parqueadero */}
        {slotsData?.map(slot => {
          const isSelected = selectedSlot?.id === slot.id;
          let color = "#4ADE80"; // Disponible (Verde)
          if (slot.status === 'occupied') color = "#EF4444"; // Ocupado (Rojo)
          else if (isSelected) color = "#FF6347"; // Seleccionado (Tomate)

          return (
            <Marker
              key={slot.id}
              position={[slot.latitude, slot.longitude]}
              eventHandlers={{ 
                click: () => { 
                  setSelectedSlot(slot); 
                  if (userLocation) trazarRuta(slot, userLocation); 
                } 
              }}
              icon={L.divIcon({
                html: `<div style="background:${color}; width:24px; height:24px; border-radius:6px; border:2px solid white; box-shadow:0 2px 5px rgba(0,0,0,0.3); transition: background 0.3s ease;"></div>`,
                className: "", iconSize: [24, 24]
              })}
            />
          );
        })}

        {/* Línea de Ruta */}
        {routePoints.length > 0 && (
          <Polyline positions={routePoints} pathOptions={{ color: '#3B82F6', weight: 5, dashArray: '8, 12', lineCap: 'round' }} />
        )}
      </MapContainer>
    </div>
  );
}