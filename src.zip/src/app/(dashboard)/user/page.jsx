"use client";
import dynamic from 'next/dynamic';
import { useState } from 'react';

// CORRECCIÓN: Apuntando al nombre de archivo correcto
const MarkingMap = dynamic(() => import('../../../components/map/MapView'), { 
  ssr: false,
  loading: () => <div className="h-screen flex items-center justify-center font-black animate-pulse bg-slate-50">SINCRONIZANDO GPS UCE...</div>
});

export default function UserDashboard() {
  const [isInside, setIsInside] = useState(true);

  return (
    <div className="h-[calc(100vh-100px)] w-full p-4 flex flex-col gap-4 bg-slate-50">
      <div className="flex-1 rounded-[3rem] overflow-hidden border-4 border-white shadow-2xl relative">
        <MarkingMap isUserInside={isInside} />
      </div>
      
      <div className="absolute top-10 left-10 z-[500] bg-white/90 px-6 py-3 rounded-2xl shadow-lg border-l-8 border-[#003366]">
        <p className="text-[10px] font-black text-gray-400 uppercase leading-tight">Navegación UCE</p>
        <p className="text-sm font-black text-[#003366] uppercase italic">GPS Activo</p>
      </div>
    </div>
  );
}