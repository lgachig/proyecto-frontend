"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../../../hooks/useAuth"; // Ajusta la ruta según tu proyecto

export default function DashboardLayout({ children }) {
  const router = useRouter();
  // AQUÍ ES DONDE DEFINES 'user' Y 'loading'
  const { user, loading } = useAuth(); 

  useEffect(() => {
    // Si ya terminó de cargar y no hay sesión, mandamos al login
    if (!loading && !user) {
      console.log("Acceso denegado: Redirigiendo al login...");
      router.push("/login");
    }
  }, [user, loading, router]);

  // Mientras verifica la sesión, mostramos el mensaje de carga
  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#003366] border-t-transparent rounded-full animate-spin mb-4 mx-auto"></div>
          <p className="font-black italic text-[#003366] uppercase tracking-tighter">
            Cargando Sistema...
          </p>
        </div>
      </div>
    );
  }

  // Si no hay usuario, no renderizamos nada (para evitar destellos de contenido protegido)
  if (!user) return null;

  return (
    <div className="min-h-screen bg-white">
      {/* Aquí puedes poner un Sidebar o Navbar si lo tienes */}
      <main className="h-screen w-full">
        {children}
      </main>
    </div>
  );
}