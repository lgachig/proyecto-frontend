"use client";
import { useEffect, useState } from "react";
import { supabase } from "../../../lib/supabase";
import { 
  ShieldCheck, 
  Car, 
  User as UserIcon, 
  Clock, 
  Search, 
  LogOut, 
  RefreshCcw,
  AlertTriangle,
  CheckCircle2
} from "lucide-react";

export default function AdminGuardPanel() {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");

  const fetchStatusGlobal = async () => {
    setLoading(true);
    // Traemos los puestos y los usuarios/vehículos vinculados
    const { data, error } = await supabase
      .from("parking_slots")
      .select(`
        id,
        number,
        status,
        user_id,
        profiles ( full_name, role )
      `)
      .order('number', { ascending: true });

    if (!error) setSlots(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchStatusGlobal();
    // Suscripción en tiempo real para que el guardia vea cambios sin refrescar
    const channel = supabase
      .channel('schema-db-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'parking_slots' }, () => {
        fetchStatusGlobal();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  // Función para que el guardia libere un puesto manualmente
  const forceRelease = async (slotId, userId) => {
    if (!confirm("¿Seguro que deseas liberar este puesto manualmente?")) return;
    
    try {
      await supabase.from("parking_slots").update({ status: 'available', user_id: null }).eq("id", slotId);
      await supabase.from("parking_sessions").update({ end_time: new Date().toISOString(), status: 'completed' }).eq("user_id", userId).eq("status", "active");
      fetchStatusGlobal();
    } catch (err) {
      console.error(err);
    }
  };

  const filteredSlots = slots.filter(s => s.number.toString().includes(filter));
  const occupiedCount = slots.filter(s => s.status === 'occupied').length;

  if (loading) return <div className="h-screen flex items-center justify-center font-black text-[#003366] animate-pulse">CARGANDO SISTEMA DE SEGURIDAD UCE...</div>;

  return (
    <div className="min-h-screen bg-gray-100 p-6 md:p-10">
      {/* HEADER DE SEGURIDAD */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-[#003366] p-3 rounded-2xl shadow-lg shadow-blue-200">
              <ShieldCheck className="text-white" size={28} />
            </div>
            <h1 className="text-4xl font-black text-[#003366] uppercase italic tracking-tighter text-balance">Panel de Guardia</h1>
          </div>
          <p className="text-gray-400 font-bold uppercase text-[10px] tracking-[0.2em] ml-1">Control de Acceso - Campus Central</p>
        </div>

        <div className="flex gap-4">
          <div className="bg-white p-4 rounded-3xl shadow-sm border-l-4 border-blue-600 flex items-center gap-4">
            <div className="text-right">
              <p className="text-[10px] font-black text-gray-400 uppercase leading-none">Ocupación</p>
              <p className="text-2xl font-black text-[#003366] leading-none mt-1">{occupiedCount}/{slots.length}</p>
            </div>
            <Car size={32} className="text-blue-100" />
          </div>
          <button onClick={fetchStatusGlobal} className="bg-white p-4 rounded-3xl shadow-sm hover:bg-blue-50 transition-colors">
            <RefreshCcw size={24} className="text-[#003366]" />
          </button>
        </div>
      </div>

      {/* BUSCADOR */}
      <div className="relative mb-8">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="BUSCAR PUESTO POR NÚMERO..."
          className="w-full pl-14 pr-6 py-5 rounded-[2rem] border-none shadow-sm font-black uppercase text-xs tracking-widest focus:ring-2 focus:ring-[#003366] transition-all"
          onChange={(e) => setFilter(e.target.value)}
        />
      </div>

      {/* MONITOR DE PUESTOS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSlots.map((slot) => (
          <div 
            key={slot.id} 
            className={`p-6 rounded-[2.5rem] shadow-sm transition-all border-2 ${
              slot.status === 'occupied' ? 'bg-white border-blue-50' : 'bg-gray-50 border-transparent opacity-80'
            }`}
          >
            <div className="flex justify-between items-start mb-6">
              <div className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-black ${
                slot.status === 'occupied' ? 'bg-[#003366] text-white shadow-lg shadow-blue-100' : 'bg-white text-gray-300 border border-gray-200'
              }`}>
                <span className="text-[9px] uppercase leading-none">Nº</span>
                <span className="text-2xl leading-none">{slot.number}</span>
              </div>
              <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase ${
                slot.status === 'occupied' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
              }`}>
                {slot.status === 'occupied' ? 'Ocupado' : 'Disponible'}
              </div>
            </div>

            {slot.status === 'occupied' ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg text-gray-500"><UserIcon size={16} /></div>
                  <p className="text-sm font-black text-gray-700 uppercase italic truncate">{slot.profiles?.full_name}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg text-gray-500"><Clock size={16} /></div>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-tighter">Estacionado desde las 08:30 AM</p>
                </div>
                
                <button 
                  onClick={() => forceRelease(slot.id, slot.user_id)}
                  className="w-full mt-4 py-4 bg-[#CC0000] hover:bg-red-700 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all shadow-lg shadow-red-50 flex items-center justify-center gap-2"
                >
                  <LogOut size={14} /> Liberar Puesto
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10">
                <CheckCircle2 size={32} className="text-green-200 mb-2" />
                <p className="text-[10px] font-black text-gray-300 uppercase">Listo para ingreso</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}