"use client";
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth'; 
import { AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function RealtimeNotifier() {
  const { profile } = useAuth();
  const [alert, setAlert] = useState(null);

  // Función para limpiar la alerta después de unos segundos
  const autoClear = () => {
    setTimeout(() => setAlert(null), 5000);
  };

  const checkGlobalStatus = useCallback(async () => {
    // Solo el Admin necesita monitorear la ocupación global
    if (profile?.role_id !== 'r003') return;

    const { data } = await supabase.from('parking_slots').select('status');
    if (!data) return;

    const total = data.length;
    const occupied = data.filter(s => s.status === 'occupied').length;
    const porcentaje = Math.round((occupied / total) * 100);

    if (porcentaje >= 100) {
      setAlert({ msg: "🔴 CAPACIDAD TOTAL", type: "danger" });
    } else if (porcentaje >= 80) {
      setAlert({ msg: `⚠️ OCUPACIÓN AL ${porcentaje}%`, type: "warning" });
    } else {
      setAlert(null); 
    }
  }, [profile]);

  useEffect(() => {
    if (!profile) return;

    const channel = supabase
      .channel('realtime-updates')
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'parking_slots' }, 
        (payload) => {
          const { new: newSlot } = payload;

          // LOGICA PARA EL USUARIO (Saber si su espacio se ocupó)
          if (profile.role_id !== 'r003') {
            if (newSlot.user_id === profile.id && newSlot.status === 'occupied') {
              setAlert({ msg: `✅ ESTACIONADO EN PUESTO ${newSlot.number}`, type: "success" });
              autoClear();
            }
          }
          
          // Refrescar el estado global si es admin
          if (profile.role_id === 'r003') {
            checkGlobalStatus();
          }
        }
      )
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [profile, checkGlobalStatus]);

  if (!alert) return null;

  const styles = {
    danger: "bg-[#CC0000] border-white",
    warning: "bg-orange-500 border-white",
    success: "bg-green-600 border-white",
    critical: "bg-black border-[#CC0000] text-yellow-400 animate-pulse"
  };

  return (
    <div className="fixed top-28 left-1/2 -translate-x-1/2 z-[99999] w-full max-w-sm px-4">
      <div className={`${styles[alert.type] || styles.warning} text-white px-8 py-5 rounded-[2.5rem] shadow-2xl flex flex-col items-center gap-1 border-4 border-white transition-all transform scale-105`}>
        <div className="flex items-center gap-4">
            {alert.type === 'success' ? <CheckCircle2 size={30} /> : <AlertTriangle size={28} />}
            <span className="font-black uppercase italic tracking-tighter text-xl text-center leading-none">
              {alert.msg}
            </span>
        </div>
      </div>
    </div>
  );
}